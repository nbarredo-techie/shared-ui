import { defineConfig } from 'vite'
import react from '@vitejs/plugin-react-swc'
import federation from '@originjs/vite-plugin-federation'

// You MUST export this object
export default defineConfig({
  plugins: [
    react(),
    federation({
      name: 'shared-ui',
      filename: 'remoteEntry.js',
      exposes: {
        './Button': './src/components/ui/button.tsx',
        './theme': './src/theme.css'
      },
      shared: ['react', 'react-dom']
    })
  ],
  build: {
    target: 'esnext',
    modulePreload: false,
    rollupOptions: {
      output: {
        format: 'system',
      }
    }
  }
})
